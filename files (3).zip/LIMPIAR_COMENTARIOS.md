# 🧹 CÓMO LIMPIAR LOS COMENTARIOS DE PRUEBA

El blog guarda los comentarios en el navegador (localStorage). Para empezar con el blog limpio sin comentarios de prueba, sigue estos pasos:

---

## 📋 Método 1: Abrir la Consola del Navegador (Recomendado)

### Paso 1: Abre el blog
- Abre el archivo `index.html` en tu navegador

### Paso 2: Abre la Consola
- **Windows/Linux:** Presiona `F12` o `Ctrl + Shift + J`
- **Mac:** Presiona `Cmd + Option + J`

### Paso 3: Ejecuta este código
Copia y pega este código en la consola y presiona Enter:

```javascript
localStorage.removeItem('comentarios_popup1');
localStorage.removeItem('comentarios_popup2');
localStorage.removeItem('comentarios_popup3');
localStorage.removeItem('comentarios_popup4');
localStorage.removeItem('comentarios_foro');
localStorage.removeItem('suscripciones');
console.log('✅ Comentarios limpiados correctamente');
```

### Paso 4: Recarga la página
- Presiona `F5` o `Ctrl + R` (Windows/Linux)
- Presiona `Cmd + R` (Mac)

---

## 📋 Método 2: Borrar Datos del Navegador

### Google Chrome:
1. Presiona `Ctrl + Shift + Delete` (Windows) o `Cmd + Shift + Delete` (Mac)
2. Selecciona "Datos de sitios web" o "Almacenamiento local"
3. Asegúrate de seleccionar "Desde siempre"
4. Haz clic en "Borrar datos"

### Firefox:
1. Presiona `Ctrl + Shift + Delete` (Windows) o `Cmd + Shift + Delete` (Mac)
2. Marca "Datos de sitios web"
3. Selecciona "Todo"
4. Haz clic en "Limpiar ahora"

### Microsoft Edge:
1. Presiona `Ctrl + Shift + Delete`
2. Marca "Almacenamiento local"
3. Selecciona "Todo el tiempo"
4. Haz clic en "Borrar ahora"

### Safari (Mac):
1. Safari > Preferencias
2. Pestaña "Privacidad"
3. Clic en "Administrar datos de sitios web"
4. Busca tu archivo local
5. Clic en "Eliminar"

---

## 📋 Método 3: Usar el Navegador en Modo Incógnito/Privado

Si quieres probar el blog limpio sin borrar nada:

- **Chrome/Edge:** `Ctrl + Shift + N` (Windows) o `Cmd + Shift + N` (Mac)
- **Firefox:** `Ctrl + Shift + P` (Windows) o `Cmd + Shift + P` (Mac)
- **Safari:** `Cmd + Shift + N`

Luego abre el archivo `index.html` en la ventana privada.

---

## 🎯 ¿Qué se borra?

Al limpiar el localStorage se eliminan:
- ✅ Todos los comentarios de prueba
- ✅ Todas las respuestas de la IA de prueba
- ✅ Correos de suscripción de prueba

**NO se elimina:**
- ✅ El sistema de comentarios (sigue funcionando)
- ✅ El sistema de respuestas de IA (sigue funcionando)
- ✅ Todo el diseño y funcionalidad del blog

---

## 🔄 ¿Cuándo limpiar los comentarios?

- **Antes de subir a GitHub:** Para que otros vean el blog vacío
- **Antes de publicar en Netlify:** Para empezar limpio
- **Después de hacer muchas pruebas:** Para empezar de nuevo

---

## ✨ Verificar que está limpio

1. Abre el blog
2. Haz clic en cualquier entrada
3. **No deberías ver ningún comentario**
4. ✅ ¡El blog está limpio y listo para usar!

---

## 🚀 Subir a GitHub/Netlify

Una vez limpio, puedes:
1. Subir el `index.html` a GitHub
2. Desplegarlo en Netlify
3. Los nuevos usuarios verán el blog sin comentarios

**Cada usuario tendrá sus propios comentarios en su navegador**, por lo que no se mezclarán.

---

## 💡 Nota Importante

Los comentarios se guardan en el **navegador de cada persona**, no en el servidor. Esto significa:
- Cada usuario solo ve sus propios comentarios
- Si borras los datos del navegador, pierdes tus comentarios
- Para comentarios compartidos entre usuarios, necesitas migrar a **Firebase** (instrucciones en GUIA_COMPLETA_IA.md)

---

**¡Listo! Ahora puedes empezar con un blog limpio y funcional.** 🎉
